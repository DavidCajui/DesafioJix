package com.jixDesafio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JixDesafioApplicationTests {

	@Test
	void contextLoads() {
	}

}
